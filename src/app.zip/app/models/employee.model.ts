export interface Employee {
    id: string
    name: string
    age: number
    category: string
}