export interface Admin {
    id: string;
    email: string;
    password: string;
}